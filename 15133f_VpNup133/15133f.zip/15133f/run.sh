mod9.12 ./all_sjkim_final1.py
setup_environment.sh python ~/bin/MSE.py
foxs *.pdb 24159_LBNL_merged_q30.dat > foxs_24159_LBNL_merged_q30.log
gnuplot *.plt

