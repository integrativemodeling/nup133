required_modules='base:atom:saxs:benchmark'
required_dependencies='Boost.ProgramOptions'
optional_dependencies=''
